var Product = require('../models/product');
var mongoose = require('mongoose');

mongoose.set('strictQuery', false);
mongoose.connect('mongodb://127.0.0.1:27017/itembase');

var products = [
    new Product({
        imagePath: "https://upload.wikimedia.org/wikipedia/en/5/5e/Gothiccover.png",
        title: 'Gothic',
        description: 'Some German Video Game',
        price: 10,
        amount: 100
    }),

    new Product({
        imagePath: "https://cdn-products.eneba.com/resized-products/BjdEY6u_350x200_1x-0.jpg",
        title: 'Dark Souls III',
        description: 'Try me',
        price: 25,
        amount: 100
    }),
    new Product({
        imagePath: "https://image.api.playstation.com/vulcan/img/cfn/11307DJTp_Y7qjNzThdkyC2xFgZ4WLz3nrhqz9tZKpvUn_2IwPxKBIPkyfj9SIrQWeOLohVvbf5wsvM_T1PjRylF-r4I5v5x.png",
        title: 'Avicii Invector',
        description: 'Think fast',
        price: 7,
        amount: 10
    }),
    new Product({
        imagePath: "https://images.igdb.com/igdb/image/upload/t_cover_big/co1pef.png",
        title: 'Shrek Extra Large',
        description: 'THE BEST',
        price: 1000,
        amount: 100
    }),
    new Product({
        imagePath: "https://image.api.playstation.com/vulcan/img/rnd/202111/3019/oXPtJkwSeNlYon2MqTX9K4sQ.png",
        title: 'Sims 4',
        description: 'You better use cheatcodes',
        price: 71,
        amount: 100
    })
];

var done = 0;
for (var i = 0; i < products.length; i++) {
    products[i].save(function(err, result) {
        done++;
        if (done === products.length) {
            exit();
        }
    });
}

function exit() {
    mongoose.disconnect();
}