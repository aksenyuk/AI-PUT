﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace MvcMovie.Controllers;

public class HelloWorldController : Controller
{
    // localhost:5001/HelloWorld/Index causes the Index method of the HelloWorldController class to run
    // GET: /HelloWorld/
    // /[Controller]/[ActionName]/[Parameters]
    // appending /HelloWorld/ to the base URL
    public IActionResult Index()
    {
        // uses a view template file to render a response to the browser
        return View();
    }
    // 
    // GET: /HelloWorld/Welcome/ 
    // So localhost:5001/HelloWorld maps to the HelloWorld Controller class
    public IActionResult Welcome(string name, int numTimes = 1)
    {
        // ViewData dictionary is a dynamic object, which means any type can be used.
        ViewData["Message"] = "Hello " + name;
        ViewData["NumTimes"] = numTimes;
        return View();
    }
}