import "bootswatch/dist/lux/bootstrap.min.css";
import './App.css';
import React, {useState} from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Books from "./screens/Books";
import Create from "./screens/Create";
import data from './initial-items.json';

function App() {
  const [books, setBooks] = useState(data)

  return (
    <div>
      <Header />
      <Routes>
        <Route path='/books' element={<Books setBooks={setBooks} books={books} />}></Route>
        <Route path='/create' element={<Create setBooks={setBooks} />} ></Route>
      </Routes>
    </div>
  );
}

export default App;
