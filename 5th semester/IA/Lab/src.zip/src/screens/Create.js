import React, { useState } from 'react';
import { Container, Form } from 'react-bootstrap';
import uniqid from 'uniqid';

const Create = ({setBooks}) => {
  const [form, setForm] = useState({ title: '', author: '', rating: '' })
  const [id, setId] = useState(uniqid()) 

  function handleChange(event) {
    const {value, name} = event.target
    setForm({ ...form, [name]: value, id })
  }

  function addBook() {
    if(form.title !== '' || form.author !== ''){
        // setBooks(book => [...book, form].sort((a, b) => b.rating - a.rating))
        setBooks(book => [...book, form])
        setId(uniqid())
        setForm({ title: '', author: '', rating: '' })
    }
  }

  return (
    <Container>
        <h1 className='mt-3'>Add Task</h1>
        <Form className='mt-3' style={{ width: "50%" }}>
            <Form.Group className="mb-3" controlId="title">
                <Form.Label>Task</Form.Label>
                <Form.Control onChange={handleChange} value={form.title} name='title' type="text" placeholder="Enter task" />
            </Form.Group>

            <Form.Group className="mb-3" controlId="author" >
                <Form.Label>Description</Form.Label>
                <Form.Control onChange={handleChange} value={form.author} name='author' type="text" placeholder="Enter task details" style={{ height: "10rem" }} />
            </Form.Group>

            <Form.Group className="mb-3" controlId="rating">
                <Form.Label>Importance</Form.Label>
                <Form.Control onChange={handleChange} value={form.rating} name='rating' type="text" placeholder="Enter how important the task is" />
            </Form.Group>
        </Form>
        <button onClick={addBook} className='btn btn-dark'>Add</button>
    </Container>
  )
}

export default Create
