import React, {useState} from 'react'
import { Card, Container, Form } from 'react-bootstrap'

const Books = ({ books, setBooks }) => {
  const [searchInput, setSearchInput] = useState("")

  function handleChange(event) {
    event.preventDefault();
    setSearchInput(event.target.value);
  }

  function findBook() {
    const foundBooks = books.find(book => book.title.toLowerCase() === searchInput.toLowerCase() || book.author.toLowerCase() === searchInput.toLowerCase())
    setBooks([books[books.indexOf(foundBooks)], ...books.filter(n => n.title !== foundBooks.title)])
  }

  function deleteBook(id) {
    setBooks(books.filter(n => n.id !== id))
  } 

  function sortBooks() {
    setBooks(book => [...book].sort((a, b) => b.rating - a.rating))
  }

  function editBook(value, book) {
    book.rating = value
  } 

  return (
    <Container className='mt-3'>
      <input className="mb-3" type="text" placeholder="Find Task" onChange={handleChange} value={searchInput} style={{ width: '18rem', height: '3rem' }} />
      <button onClick={findBook} className='btn btn-dark ms-3'>Search</button>
      <button onClick={sortBooks} className='btn btn-dark ms-3'>Sort Tasks</button>
      {books.map(book => (
        <Card className="mb-3" key={book.id} style={{ width: '18rem' }}>
            <Card.Img src="https://balancethroughsimplicity.com/wp-content/uploads/2020/04/How-to-write-a-To-Do-list-to-get-things-done-BLOG-1.jpg" />
            {/* <Card.Img src="https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fA%3D%3D&w=1000&q=80" /> */}
            <Card.Body>
                <Card.Title>Task: {book.title}</Card.Title>
                <Card.Text>Description: {book.author}</Card.Text>
                <Form.Group className="mb-3" controlId="rating">
                    <Form.Label>Importance</Form.Label>
                    <Form.Control onChange={(e) => editBook(e.target.value, book)} name='rating' type="text" placeholder={book.rating} />
                </Form.Group>
                <i class="fa fa-trash float-end" onClick={() => deleteBook(book.id)}></i>
            </Card.Body>
        </Card>
      ))}
    </Container>
  )
}

export default Books
