import React from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import { Container, Nav, Navbar } from 'react-bootstrap';

const Header = () => {
  return (
    <div>
      <Container> 
        <Navbar bg="dark" expand="lg">
          <Navbar.Brand className='ms-3' style={{color:"white"}}>To-Do List</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <LinkContainer to='/create' style={{color:"white"}}>
                <Nav.Link>Home</Nav.Link>
              </LinkContainer>
              <LinkContainer to='/books' style={{color:"white"}}>
                <Nav.Link>Tasks</Nav.Link>
              </LinkContainer>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
      </Container>
    </div>
  )
}

export default Header
