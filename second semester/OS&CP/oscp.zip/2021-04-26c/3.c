#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>

void die(const char *msg);

int main(int argc, char **argv)
{
    int f;
    size_t bytes, wds, lines;
    int inside_wd;

    if (argc < 2 || !strcmp(argv[1], "-")) {
        f = 0;
    } else if ((f = open(argv[1], O_RDONLY)) < 0)
        die("failed to open file\n");

    bytes = wds = lines = 0;
    inside_wd = 0;
    char c;
    while (read(f, &c, 1) > 0) {
        bytes++;
        wds += (!inside_wd && !isspace(c));
        inside_wd = !isspace(c);
        lines += (c == '\n');
    }

    printf("%zu\t%zu\t%zu\n", lines, wds, bytes);

    close(f);
    return 0;
}

void die(const char *msg)
{
    fputs(msg, stderr);
    exit(1);
}
