#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

/* Arbitrary initial buffer size for a line */
#define BUF_SIZE 512

typedef struct {
    char **lines;
    size_t linec;
    size_t *line_sizes;
} File;

void die(const char *msg);
int getLine(int file, char **buf_ptr, size_t *bufsize);
File *fileLoad(const char *path);
void fileFree(File *file);

int main(int argc, char **argv)
{
    if (argc != 3)
        die("exactly 2 arguments required\n");

    File *f1, *f2;
    f1 = fileLoad(argv[1]);
    f2 = fileLoad(argv[2]);

    size_t i = 0, j = 0;
    while (i < f1->linec && j < f2->linec) {
        if (0 > strcmp(f1->lines[i], f2->lines[j])) {
            puts(f1->lines[i]);
            puts(f2->lines[j]);
        } else {
            puts(f2->lines[j]);
            puts(f1->lines[i]);
        }
        ++i, ++j;
    }
    while (i < f1->linec) {
        puts(f1->lines[i++]);
    }
    while (j < f2->linec) {
        puts(f2->lines[j++]);
    }

    fileFree(f1);
    fileFree(f2);
    return 0;
}

void die(const char *msg)
{
    fputs(msg, stderr);
    exit(1);
}

int getLine(int file, char **buf_ptr, size_t *bufsize)
{
    size_t pos; /* Current position in the buffer */
    char c;     /* Last read character from file */
    int ret;    /* read's return code */

    /* Read character-by-character until newline */
    pos = 0;
    ret = read(file, &c, 1);
    while (ret > 0 && c != '\n') {

        /* Enlarge buffer if needed */
        if (pos == *bufsize - 1) {
            *bufsize *= 2;
            if (!(*buf_ptr = realloc(*buf_ptr, *bufsize * sizeof **buf_ptr)))
                die("realloc\n");
        }

        (*buf_ptr)[pos++] = c;
        ret = read(file, &c, 1);
    }

    /* Terminate the string */
    (*buf_ptr)[pos] = '\0';

    return (ret <= 0)? EOF : 0;
}

File *fileLoad(const char *path)
{
    File *ret;
    int f;

    if (!(ret = malloc(sizeof *ret)))
        die("malloc\n");
    if ((f = open(path, O_RDONLY)) < 0)
        die("failed to open file");
    ret->linec = 1;
    int c;
    while (read(f, &c, 1) > 0) {
        ret->linec += (c == '\n');
    }

    if (!(ret->lines = malloc(ret->linec * sizeof *ret->lines)))
        die("malloc\n");
    if (!(ret->line_sizes = malloc(ret->linec * sizeof *ret->line_sizes)))
        die("malloc\n");
    for (size_t i = 0; i < ret->linec; i++) {
        ret->line_sizes[i] = BUF_SIZE;
        if (!(ret->lines[i] = malloc(ret->line_sizes[i] * sizeof **ret->lines)))
            die("malloc\n");
    }

    lseek(f, 0, SEEK_SET);
    for (size_t i = 0; i < ret->linec; i++) {
        getLine(f, ret->lines + i, ret->line_sizes + i);
    }

    /* If last line is blank, remove it */
    if (ret->lines[ret->linec - 1][0] == '\0') {
        ret->linec--;
        free(ret->lines[ret->linec]);
    }

    close(f);
    return ret;
}

void fileFree(File *file)
{
    for (size_t i = 0; i < file->linec; i++)
        free(file->lines[i]);
    free(file->lines);
    free(file->line_sizes);
    free(file);
}
