#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

/* Arbitrary initial buffer size for a line */
#define BUF_SIZE 4096

void die(const char *msg);
int getLine(int file, char **buf_ptr, size_t *bufsize);

int main(int argc, char **argv)
{
    if (argc != 3)
        die("exactly 2 arguments required\n");

    int f;
    const char *query;
    size_t query_len;
    char *buf;
    size_t buf_size;

    query = argv[1];
    query_len = strlen(query);
    if ((f = open(argv[2], O_RDONLY)) < 0)
        die("failed to open file");

    buf_size = BUF_SIZE;
    if (!(buf = malloc(buf_size * sizeof *buf)))
        die("malloc\n");

    while (EOF != getLine(f, &buf, &buf_size)) {
        if (!strncmp(buf, query, query_len))
            puts(buf);
    }

    close(f);
    free(buf);
    return 0;
}

void die(const char *msg)
{
    fputs(msg, stderr);
    exit(1);
}

int getLine(int file, char **buf_ptr, size_t *bufsize)
{
    size_t pos; /* Current position in the buffer */
    char c;     /* Last read character from file */
    int ret;    /* read's return code */

    /* Read character-by-character until newline */
    pos = 0;
    ret = read(file, &c, 1);
    while (ret > 0 && c != '\n') {

        /* Enlarge buffer if needed */
        if (pos == *bufsize - 1) {
            *bufsize *= 2;
            if (!(*buf_ptr = realloc(*buf_ptr, *bufsize * sizeof **buf_ptr)))
                die("realloc\n");
        }

        (*buf_ptr)[pos++] = c;
        ret = read(file, &c, 1);
    }

    /* Terminate the string */
    (*buf_ptr)[pos] = '\0';

    return (ret <= 0)? EOF : 0;
}
