#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#define PERMS 0644

void die(const char *msg);

int main(int argc, char **argv)
{
    if (argc < 2)
        die("at least 1 argument required\n");

    int f;
    const char *fpath = NULL;
    int flag = O_TRUNC;

    /* Parse arguments */
    if (argc < 3) {
        fpath = argv[1];
    } else {
        if (!strcmp(argv[1], "-a")) {
            flag = O_APPEND;
        } else {
            die("invalid option\n");
        }
        fpath = argv[2];
    }

    if ((f = open(fpath, O_WRONLY | O_CREAT | flag, PERMS)) < 0)
        die("failed to open file\n");

    char c;
    while (EOF != (c = getchar())) {
        write(f, &c, 1);
        write(1, &c, 1);
    }

    close(f);
    return 0;
}

void die(const char *msg)
{
    fputs(msg, stderr);
    exit(1);
}
