#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

void die(const char *msg);

int main(int argc, char **argv)
{
    if (argc != 3)
        die("exactly 2 arguments required\n");

    int f1, f2;
    size_t byte, line;
    int diff_found = 0;

    if ((f1 = open(argv[1], O_RDONLY)) < 0)
        die("failed to open file 1");
    if ((f2 = open(argv[2], O_RDONLY)) < 0)
        die("failed to open file 2");

    byte = line = 1;
    char c1, c2;
    size_t ret1, ret2;
    do {
        ret1 = read(f1, &c1, 1);
        ret2 = read(f2, &c2, 1);
        line += (c1 == '\n');
        byte++;
    } while (c1 == c2 && ret1 && ret2);

    if (ret1 || ret2)
        diff_found = 1;

    if (diff_found) {
        printf("%s %s differ: byte %zu, line %zu\n",
                argv[1], argv[2], byte, line);
    }

    close(f1);
    close(f2);
    return diff_found;
}

void die(const char *msg)
{
    fputs(msg, stderr);
    exit(2);
}
