length, edits = map(int, (list(input().split())))
word = input()
longest = word
for i in range(edits):
    operations = input().split(";")
    operations[0], operations[1] = map(int, operations[0:2])
    a, b = operations[0], operations[1]
    word = word[:min(a, b)] + operations[2] + word[max(a, b) + 1:]
    if len(word) > len(longest):
        longest = word
print(word)
print(longest)
